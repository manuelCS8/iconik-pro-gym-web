// src/config/firebase.ts - Mock Firebase para React Native/Expo
// Esta configuración evita errores de inicialización mientras desarrollas

// 🧪 MODO ACTUAL: MOCK/DEMO
// Para cambiar a Firebase real, sigue las instrucciones en FIREBASE_SETUP.md
const USE_MOCK_FIREBASE = true; // ⚠️ Cambiar a false para usar Firebase real

console.log(USE_MOCK_FIREBASE ? "🧪 Firebase: Usando modo Mock para desarrollo" : "🔥 Firebase: Usando configuración real");

import { initializeApp } from "firebase/app";
import { getFirestore, serverTimestamp } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDZoK4MZ8ORqD6nfMswbZMLmSNsZoS1X-w",
  authDomain: "conikprogym.firebaseapp.com",
  projectId: "conikprogym",
  storageBucket: "conikprogym.firebasestorage.app",
  messagingSenderId: "113622948013",
  appId: "1:113622948013:web:5eecb446a91a47d1b44e24"
};

const app = initializeApp(firebaseConfig);

export const firestore = getFirestore(app);
export const storage = getStorage(app);
export { serverTimestamp };

// --- AUTH REST API ---
const FIREBASE_API_KEY = firebaseConfig.apiKey;

export async function signInWithEmailAndPassword(email, password) {
  const res = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FIREBASE_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, returnSecureToken: true })
    }
  );
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || "Error al iniciar sesión");
  return data;
}

export async function createUserWithEmailAndPassword(email, password) {
  const res = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${FIREBASE_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, returnSecureToken: true })
    }
  );
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || "Error al registrarse");
  return data;
}

// Auth functions
export const signOut = async () => Promise.resolve();

export const onAuthStateChanged = (callback: (user: any) => void) => {
  if (typeof callback === 'function') {
    setTimeout(() => callback(null), 100);
  }
  return () => {};
};

export const sendPasswordResetEmail = async () => Promise.resolve();

// Firestore functions
export const doc = () => ({});
export const getDoc = async () => ({ exists: () => false, data: () => ({}) });
export const setDoc = async () => Promise.resolve();
export const updateDoc = async () => Promise.resolve();
export const collection = () => ({});
export const addDoc = async () => Promise.resolve({ id: "mock-id" });
export const query = () => ({});
export const where = () => ({});
export const getDocs = async () => ({ docs: [] });
export const orderBy = () => ({});
export const limit = () => ({});
export const Timestamp = { now: () => new Date() };

// Storage functions
export const ref = () => ({});
export const uploadBytes = async () => Promise.resolve();
export const getDownloadURL = async () => "https://mock-url.com/file.jpg";
export const deleteObject = async () => Promise.resolve();

// Export configuration flag
export { USE_MOCK_FIREBASE };

// ⚠️ CONFIGURACIÓN ACTUAL: MODO MOCK/DEMO
// 
// ✅ CREDENCIALES QUE FUNCIONAN:
// 🛠️ Admin: admin@iconik.com / admin123
// 👤 Miembro: member@iconik.com / member123
//
// ❌ CREDENCIALES REALES NO FUNCIONAN en modo mock
// 
// 🔥 PARA USAR FIREBASE REAL:
// 1. Cambia USE_MOCK_FIREBASE a false
// 2. Sigue las instrucciones en FIREBASE_SETUP.md
// 3. Reemplaza este archivo con la configuración real de Firebase 
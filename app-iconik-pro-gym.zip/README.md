# 🏋️‍♂️ Iconik Pro Gym - App de Gestión de Gimnasio

Una aplicación móvil completa para la gestión de gimnasios desarrollada con **React Native + Expo**, diseñada para administradores y miembros.

## 🚀 Características Principales

### 👤 **Para Miembros**
- ✅ **Rutinas Personalizadas** - Crea y sigue rutinas de ejercicio
- ✅ **Explorador de Ejercicios** - Base de datos completa con videos
- ✅ **Tracking de Entrenamientos** - Registro offline de series, reps y peso
- ✅ **Sincronización Automática** - Los datos se sincronizan al restaurar conexión
- ✅ **Perfil Personalizable** - BMI, objetivos y estadísticas

### 🛠️ **Para Administradores**
- ✅ **Dashboard Completo** - Estadísticas en tiempo real
- ✅ **Gestión de Miembros** - CRUD completo de usuarios
- ✅ **Gestión de Ejercicios** - Administrar base de datos de ejercicios
- ✅ **Gestión de Rutinas** - Crear y administrar rutinas del gimnasio
- ✅ **Control de Acceso** - Sistema de roles y permisos

### 🔧 **Características Técnicas**
- 📱 **React Native 0.79** + **Expo 53**
- 🔥 **Firebase** (Firestore, Storage, Auth)
- 💾 **SQLite** para almacenamiento offline
- 🔄 **Redux Toolkit** para manejo de estado
- 📡 **Sincronización Offline** automática
- 🎨 **UI/UX Moderna** con navegación fluida

## 📱 Instalación y Configuración

### Prerrequisitos
```bash
Node.js >= 18
npm >= 9
Expo CLI
```

### 1. Clonar e Instalar
```bash
git clone [tu-repositorio]
cd app-iconik-pro-gym
npm install --legacy-peer-deps
```

### 2. Configurar Firebase
```bash
# Crear proyecto en Firebase Console
# Habilitar: Authentication, Firestore, Storage
# Descargar google-services.json / GoogleService-Info.plist
```

### 3. Ejecutar la App
```bash
# Desarrollo
npm start

# Android
npm run android

# iOS  
npm run ios
```

## 🗂️ Estructura del Proyecto

```
src/
├── components/          # Componentes reutilizables
│   ├── ConnectionStatus.tsx
│   ├── RoleGuard.tsx
│   └── ...
├── navigation/          # Configuración de navegación
│   ├── AppNavigator.tsx
│   ├── AdminNavigator.tsx
│   └── MemberNavigator.tsx
├── screens/            # Pantallas de la app
│   ├── admin/          # Pantallas de administrador
│   ├── member/         # Pantallas de miembros
│   └── shared/         # Pantallas compartidas
├── redux/              # Estado global
│   ├── slices/
│   └── store.ts
├── services/           # Servicios y lógica de negocio
│   ├── syncService.ts
│   ├── sqliteService.ts
│   └── ...
├── config/             # Configuraciones
│   └── firebase.ts
└── utils/              # Utilidades y helpers
    ├── theme.ts
    └── ...
```

## 👥 Usuarios de Demo

### Administrador
- **Email:** `admin@iconik.com`
- **Contraseña:** Demo (demoLogin)

### Miembro
- **Email:** `member@iconik.com`  
- **Contraseña:** Demo (demoLogin)

## 🔄 Sistema de Sincronización

La app funciona **100% offline** y sincroniza automáticamente:

- ✅ **Entrenamientos** se guardan en SQLite
- ✅ **Sincronización automática** al detectar conexión
- ✅ **Indicador visual** del estado de sincronización
- ✅ **Sin pérdida de datos** garantizada

## 🎨 Diseño y UI

- **Colores:** Rojo principal `#E31C1F`, grises y blancos
- **Tipografía:** Consistente en toda la app
- **Responsive:** Adaptable a diferentes tamaños de pantalla
- **Accesibilidad:** Cumple estándares de accesibilidad

## 📱 Compilación para Producción

### Android APK
```bash
npx eas build --platform android --profile preview
```

### Android AAB (Play Store)
```bash
npx eas build --platform android --profile production
```

### iOS (App Store)
```bash
npx eas build --platform ios --profile production
```

## 🔧 Tecnologías Utilizadas

| Categoría | Tecnología |
|-----------|------------|
| **Framework** | React Native 0.79 + Expo 53 |
| **Estado** | Redux Toolkit |
| **Navegación** | React Navigation 7 |
| **Base de Datos** | Firebase Firestore + SQLite |
| **Almacenamiento** | Firebase Storage |
| **Autenticación** | Firebase Auth |
| **Conectividad** | @react-native-community/netinfo |
| **Iconos** | @expo/vector-icons |
| **Gráficos** | Victory Native |

## 🛡️ Seguridad

- ✅ **Autenticación** con Firebase Auth
- ✅ **Roles y permisos** (Admin/Member)
- ✅ **Validación** de formularios
- ✅ **Guards de navegación** por rol
- ✅ **Datos encriptados** en tránsito

## 📊 Estado del Proyecto

| Feature | Estado |
|---------|--------|
| ✅ Autenticación | **Completo** |
| ✅ Dashboard Admin | **Completo** |
| ✅ Gestión Miembros | **Completo** |
| ✅ Gestión Ejercicios | **Completo** |
| ✅ Gestión Rutinas | **Completo** |
| ✅ Tracking Entrenamientos | **Completo** |
| ✅ Sincronización Offline | **Completo** |
| ✅ UI/UX Consistente | **Completo** |

## 🚀 Próximos Pasos

1. **Activar Firebase Production** (tras verificación de pago)
2. **Subir a Play Store/App Store**
3. **Testing beta** con usuarios reales
4. **Optimizaciones de rendimiento**

## 📞 Soporte

Para soporte técnico o preguntas sobre el proyecto:
- **Email:** [tu-email]
- **GitHub:** [tu-github]

---

**Iconik Pro Gym** - Desarrollado con ❤️ usando React Native + Expo 